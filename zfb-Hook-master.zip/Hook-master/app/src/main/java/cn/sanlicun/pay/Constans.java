package cn.sanlicun.pay;

/**
 * Created by 小饭 on 2018/7/5.
 */

public class Constans {
    public static final String WECHAT_PACKAGE = "com.tencent.mm";

    public static final String ACTION_LAUNCH_WECHAT_WALLET = "cn.sanlicun.action.wechat";
    public static final String ACTION_LAUNCH_ALIPAY_WALLET = "cn.sanlicun.action.alipay";

    public static final String ACTION_PAY_SUCCESS = "cn.sanlicun.pay.action.pay_success";


    public static final String ALIPAY_PACKAGE = "com.eg.android.AlipayGphone";
    public static final String ALIPAY_WALLET_ACTIVITY_NAME = "com.alipay.mobile.onsitepay9.payer.OspTabHostActivity";
    public static final String ALIPAY_CORE_SERVICE_NAME = "com.alipay.android.phone.nfd.nfdservice.ui.app.NfdService";

    public  static  final  String   SETMONEYACTIVITY="com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity";
    public  static  final  String  ALIPAYNAME="com.eg.android.AlipayGphone";
    public  static  final  String SETAMOUNTRES="com.alipay.transferprod.rpc.result.ConsultSetAmountRes";
    public static final String MARK = "mark";
    public static final String MONEY = "money";
    public static final String  QRCODE_RESULT = "cn.sanlicun.qrcode_result";
    public static final String WECHAT_QRCODE = "com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI";
    public static final String PAY_URL = "payurl";
    public static final String TYPE = "type";
    public static final String  WECHAT = "wechat";
    public static final String ALIPAY = "alipay";
    public static final String BILL_NO = "bill_no";
    public static final String BILL_MONEY = "bill_money";
    public static final String BILL_MARK = "bill_mark";
    public static final String BILL_TYPE = "bill_type";

    public  static  final  String WECHAT_WALLET="com.tencent.mm.wallet_core.ui.formview.WalletFormView";

    public  static  final  String WECHAT_SQL="com.tencent.wcdb.database.SQLiteDatabase";
    public  static  final  String ALI_SQL="com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao";


    public static final CharSequence QQ = "com.tencent.mobileqq";
    public static final String  ACTION_LAUNCH_QQ_WALLET = "cn.sanlicun.action.qq";
    public static final String MESSAGE_RECEIVED_ACTION = "com.example.jpushdemo.MESSAGE_RECEIVED_ACTION";
}
