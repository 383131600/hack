# alipay
xponsed 下 先打开软件 在打开支付宝  回到软件进行测试